using MongoDB.Driver;
using System.Threading;
using System.Threading.Tasks;
using ClientAPI.Domain.Entities;

namespace ClientAPI.Application.Interfaces;

public interface IApplicationDbContext
{
    IMongoCollection<Client> Client { get; }
    
    Task<int> SaveChangesAsync(CancellationToken cancellationToken );
}