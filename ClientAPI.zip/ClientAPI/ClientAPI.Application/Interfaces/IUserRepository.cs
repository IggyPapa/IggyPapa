using ClientAPI.Domain.Entities;

namespace ClientAPI.Application.Interfaces;

public interface IUserRepository
{
    Task<bool> UsernameExistsAsync(string username);
    Task<Client> GetByUsernameAsync(string username);
    Task UpdateAsync(Client client);
    Task<List<Client>> GetUsersByFriendPendingAsync(Guid clientId);
    Task<List<Client>> GetUsersByIdsAsync(IEnumerable<Guid> ids);
    
}