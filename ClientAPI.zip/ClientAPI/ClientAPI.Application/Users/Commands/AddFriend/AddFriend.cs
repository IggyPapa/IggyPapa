using ClientAPI.Domain.Enums;
using MediatR;


namespace ClientAPI.Application.Users.Commands.AddFriend;

public class AddFriend : IRequest<bool>
{
    public string ClientUsername { get; set; }
    public string FriendUsername { get; set; }
}

