using ClientAPI.Application.Interfaces;
using ClientAPI.Domain.Entities;
using ClientAPI.Domain.Enums;
using MediatR;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ClientAPI.Application.Users.Commands.AddFriend
{
    public class AddFriendHandler : IRequestHandler<AddFriend, bool>
    {
        private readonly IUserRepository _userRepository;

        public AddFriendHandler(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<bool> Handle(AddFriend request, CancellationToken cancellationToken)
        {
            // Basic input guard
            if (string.IsNullOrWhiteSpace(request.ClientUsername) ||
                string.IsNullOrWhiteSpace(request.FriendUsername))
            {
                return false;
            }

            // Load both users
            var client = await _userRepository.GetByUsernameAsync(request.ClientUsername);
            var friend = await _userRepository.GetByUsernameAsync(request.FriendUsername);

            if (client == null || friend == null) return false;
            if (client.Id == friend.Id) return false; // no self-requests

            // Ensure lists (Mongo may return null when field missing)
            client.Friend ??= new List<ClientFriend>();

            // If already present (Pending or Accepted) => idempotent no-op
            var existing = client.Friend.FirstOrDefault(f => f != null && f.FriendId == friend.Id);
            if (existing != null) return false;

            // Create new pending request
            client.Friend.Add(new ClientFriend
            {
                ClientId = client.Id,
                FriendId = friend.Id,
                Status = RequestStatus.Pending
            });

            await _userRepository.UpdateAsync(client);
            return true;
        }
    }
}