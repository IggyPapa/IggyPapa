using ClientAPI;
using ClientAPI.Application.Interfaces;
using FluentValidation;

namespace ClientAPI.Application.Users.Commands.RegisterUser;

public class RegisterUserValidator : AbstractValidator<RegisterUser>
{
    
    private readonly IUserRepository _userRepository;
    public RegisterUserValidator(IUserRepository userRepository)
    {
        _userRepository = userRepository;
        
        RuleFor( x => x.Username)
            .NotEmpty().WithMessage("Username is required.")
            .MustAsync(async (username, cancellation) =>
                !await _userRepository.UsernameExistsAsync(username))
            .WithMessage("Username already exists.");
        
        RuleFor( x => x.Password)
            .NotEmpty().WithMessage("Password is required.")
            .MinimumLength(10).WithMessage("Password must be at least 8 characters long.");
            
        RuleFor( x => x.Password)
            .NotEmpty().WithMessage("Password is required.")
            .Must(ValidDate).WithMessage("Date of Birth must not be in the future.");
            
    }

    private bool ValidDate(string date)
    {
        return DateTime.TryParse(date, out _);
    }
    
}