using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;
using MongoDB.Driver;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Identity;
using ClientAPI.Application.Interfaces;
using ClientAPI.Domain.Entities;


namespace ClientAPI.Application.Users.Commands.RegisterUser;

public class RegisterUserHandler : IRequestHandler<RegisterUser, Guid>
{
    private readonly IApplicationDbContext _dbContext;
    private readonly IPasswordHasher<Client> _passwordHasher;

    public RegisterUserHandler(IApplicationDbContext dbContext, IPasswordHasher<Client> passwordHasher)
    {
        _dbContext = dbContext;
        _passwordHasher = passwordHasher;
    }

    public async Task<Guid> Handle(RegisterUser request, CancellationToken cancellationToken)
    {

        // Checking if Username Exists
        var existingUser = await _dbContext.Client
            .Find(u => u.Username == request.Username)
            .FirstOrDefaultAsync(cancellationToken);

        if (existingUser != null)
        {
            throw new Exception("Username already exists");
        }
        
        // Creates a new user Identity
        var user = new Client
        {
            Id = Guid.NewGuid(),
            Username = request.Username,
            DoB = request.DoB,
        };
        
        // Hashes Password
        user.Password = _passwordHasher.HashPassword(user, request.Password);


        // Saves User to MongoDB
        await _dbContext.Client.InsertOneAsync(user, cancellationToken:  cancellationToken);

        return user.Id;
    }


}