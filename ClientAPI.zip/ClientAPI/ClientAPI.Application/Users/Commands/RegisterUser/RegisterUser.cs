using MediatR;

namespace ClientAPI.Application.Users.Commands.RegisterUser;

public class RegisterUser : IRequest<Guid>
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string DoB { get; set; }

    public RegisterUser(string username, string password, string dob)
    {
        Username = username;
        Password = password;
        DoB = dob;
    }
}