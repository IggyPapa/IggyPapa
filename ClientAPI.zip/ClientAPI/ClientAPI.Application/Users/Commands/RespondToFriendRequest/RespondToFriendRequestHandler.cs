using ClientAPI.Application.Users.Commands.RespondToFriendRequest;
using ClientAPI.Domain.Entities;
using ClientAPI.Domain.Enums;
using MediatR;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ClientAPI.Application.Interfaces;

namespace ClientAPI.Application.Users.Commands.RespondToFriendRequest;

public class RespondToFriendRequestHandler :  IRequestHandler<RespondToFriendRequest, bool>
{
    private readonly IUserRepository _userRepository;

    public RespondToFriendRequestHandler(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<bool> Handle(RespondToFriendRequest request, CancellationToken cancellationToken)
    {
        var receiver = await _userRepository.GetByUsernameAsync(request.ReceiverUsername);
        var sender = await _userRepository.GetByUsernameAsync(request.SenderUsername);

        if (sender == null || receiver == null) { return false; }
        
        var senderEntry = sender.Friend?.FirstOrDefault(f => f.FriendId == receiver.Id);
        if (senderEntry == null || senderEntry.Status != RequestStatus.Pending ) { return false; }

        if (request.isAccepted)
        {
            senderEntry.Status = RequestStatus.Accepted;

            if (receiver.Friend == null) { receiver.Friend = new List<ClientFriend>(); }

            if (!receiver.Friend.Any(f => f.FriendId == sender.Id))
            {
                receiver.Friend.Add(new ClientFriend
                {
                    ClientId = receiver.Id,
                    FriendId = sender.Id,
                    Status = RequestStatus.Accepted
                });
            }
        }
        else
        {
            sender.Friend.RemoveAll(f => f.FriendId == receiver.Id);
        }
        
        await _userRepository.UpdateAsync(sender);
        await _userRepository.UpdateAsync(receiver);

        return true;
    }
}