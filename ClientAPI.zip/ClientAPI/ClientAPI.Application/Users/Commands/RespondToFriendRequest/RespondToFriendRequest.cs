using MediatR;

namespace ClientAPI.Application.Users.Commands.RespondToFriendRequest;

public class RespondToFriendRequest : IRequest<bool>
{
    public string SenderUsername { get; set; }
    public string ReceiverUsername { get; set; }
    public bool isAccepted { get; set; }
}