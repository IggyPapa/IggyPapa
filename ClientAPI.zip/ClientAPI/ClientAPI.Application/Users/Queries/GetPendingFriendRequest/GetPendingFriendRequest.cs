using MediatR;

namespace ClientAPI.Application.Users.Queries.GetPendingFriendRequest;

public class GetPendingFriendRequest : IRequest<List<FriendRequestDTO>>
{
    public string Username { get; set; }
}