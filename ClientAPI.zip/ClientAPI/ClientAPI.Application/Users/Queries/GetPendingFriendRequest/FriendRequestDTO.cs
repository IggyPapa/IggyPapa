namespace ClientAPI.Application.Users.Queries.GetPendingFriendRequest;

public class FriendRequestDTO
{
    public string SenderUsername { get; set; }
}