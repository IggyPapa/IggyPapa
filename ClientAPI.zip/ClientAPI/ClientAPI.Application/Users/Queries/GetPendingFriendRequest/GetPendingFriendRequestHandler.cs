using ClientAPI.Application.Users.Commands.RespondToFriendRequest;
using ClientAPI.Domain.Entities;
using ClientAPI.Domain.Enums;
using ClientAPI.Application.Interfaces;
using ClientAPI.Application.Users.Queries.GetPendingFriendRequest;
using MediatR;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ClientAPI.Application.Users.Queries.GetPendingFriendRequest;

public class GetPendingFriendRequestHandler : IRequestHandler<GetPendingFriendRequest, List<FriendRequestDTO>>
{
    private readonly IUserRepository _userRepository;

    public GetPendingFriendRequestHandler(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<List<FriendRequestDTO>> Handle(GetPendingFriendRequest request, CancellationToken cancellationToken)
    {
        var client = await _userRepository.GetByUsernameAsync(request.Username);
        if (client == null || client.Friend == null) { return new List<FriendRequestDTO>(); }
        
        var pendingSenders = await _userRepository.GetUsersByFriendPendingAsync(client.Id);

        return pendingSenders.Select(s => new FriendRequestDTO
        {
            SenderUsername = s.Username
        }).ToList();
    }
    
    
    
}