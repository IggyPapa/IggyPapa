﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text.Json;

class Program
{
    static async Task Main(string[] args)
    {
        var tokenEndpoint = "https://localhost:5001/connect/token";

        var clientId = "ro.client";
        var clientSecret = "secret";
        var username = "mike";
        var password = "secret3";
        var scope = "openid profile api1 offline_access";

        using var client = new HttpClient();

        var request = new HttpRequestMessage(HttpMethod.Post, tokenEndpoint);

        var parameters = new Dictionary<string, string>
        {
            { "client_id", clientId },
            { "client_secret", clientSecret },
            { "grant_type", "password" },
            { "username", username },
            { "password", password },
            { "scope", scope }
        };

        request.Content = new FormUrlEncodedContent(parameters);

        var response = await client.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            Console.WriteLine($"Error: {response.StatusCode}");
            var errorContent = await response.Content.ReadAsStringAsync();
            Console.WriteLine(errorContent);
            return;
        }

        var content = await response.Content.ReadAsStringAsync();

        var jsonDoc = JsonDocument.Parse(content);
        if (jsonDoc.RootElement.TryGetProperty("access_token", out var accessToken))
        {
            Console.WriteLine("Access Token:");
            Console.WriteLine(accessToken.GetString());
        }
        else
        {
            Console.WriteLine("Token not found in response:");
            Console.WriteLine(content);
        }
    }
}