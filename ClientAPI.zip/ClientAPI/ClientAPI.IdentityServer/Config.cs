using IdentityServer4.Models;
using IdentityServer4.Test;
using System.Security.Claims;

namespace ClientAPI.IdentityServer;

public class Config
{
    public static IEnumerable<IdentityResource> IdentityResources =>
        new IdentityResource[]
        {
            new IdentityResources.OpenId(),
            new IdentityResources.Profile(),
        };

    public static IEnumerable<ApiScope> ApiScopes =>
        new ApiScope[]
        {
            new ApiScope("api1", "My API")
        };
    
    public static IEnumerable<ApiResource> ApiResources => new[]
    {
        new ApiResource("api1", "My API")
        {
            Scopes = { "api1" }
        }
    };

    public static IEnumerable<Client> Clients =>
        new Client[]
        {
            
            new Client
            {
                ClientId = "client",
                AllowedGrantTypes = GrantTypes.ClientCredentials,
                
                ClientSecrets =
                {
                    new Secret("secret".Sha256())
                },
                AllowedScopes = { "api1" }
            },
            
            new Client
            {
            ClientId = "ro.client",
            AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,

            ClientSecrets = { new Secret("secret".Sha256()) },

            AllowedScopes = { "openid", "profile", "api1", "offline_access" },

            AllowOfflineAccess = true,
            }
        };
    
    public static List<TestUser> GetUsers() =>
        new List<TestUser>
        {
            new TestUser
            {
                SubjectId = "1",
                Username = "alice",
                Password = "password",
                Claims = new[]
                {
                    new Claim("name", "Alice"),
                    new Claim("website", "https://alice.com")
                }
            }
        };
}