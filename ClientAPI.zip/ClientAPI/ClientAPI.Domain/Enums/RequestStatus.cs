namespace ClientAPI.Domain.Enums;

public enum RequestStatus
{
    Pending,
    Accepted
}