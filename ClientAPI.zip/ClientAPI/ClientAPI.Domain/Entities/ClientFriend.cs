using ClientAPI.Domain.Enums;
namespace ClientAPI.Domain.Entities;

public class ClientFriend
{
    public Guid ClientId { get; set; } 
    public Guid FriendId { get; set; } 
    public RequestStatus Status { get; set; } = RequestStatus.Pending;

}