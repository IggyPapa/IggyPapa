﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ClientAPI.Domain.Entities;

public class Client
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string DoB { get; set; }
    [BsonId]
    [BsonRepresentation(BsonType.String)]
    public Guid Id { get; set; } =  Guid.NewGuid();

    public List<ClientFriend> Friend { get; set; } = new();
}