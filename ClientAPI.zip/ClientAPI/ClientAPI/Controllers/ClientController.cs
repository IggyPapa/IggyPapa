using ClientAPI.Application.Interfaces;
using ClientAPI.Application.Users.Commands.RegisterUser;
using ClientAPI.Application.Users.Commands.UserLogin;
using ClientAPI.Application.Users.Commands.AddFriend;
using ClientAPI.Application.Users.Commands.RespondToFriendRequest;
using ClientAPI.Application.Users.Queries.GetPendingFriendRequest;
using ClientAPI.Domain.Entities;
using ClientAPI.Domain.Enums;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Threading;
using System.Threading.Tasks;
using System.Text.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using IdentityModel;
using Microsoft.AspNetCore.Authorization;

namespace ClientAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class ClientController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher<ClientAPI.Domain.Entities.Client> _passwordHasher;

    public ClientController(
        IMediator mediator
        , IUserRepository userRepository
        , IPasswordHasher<ClientAPI.Domain.Entities.Client> passwordHasher)
    {
        _mediator = mediator;
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        
    }
    
    //public AuthController(I)
    [AllowAnonymous]
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterUser request)
    {
        var userId = await _mediator.Send(request);
        return Ok( new { UserId = userId }); 
        // might need to be changes to just Id opos to eshis sto Entity Class tou Client
    }
    
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromForm] LoginRequest request)
    {
        var user = await _userRepository.GetByUsernameAsync(request.Username);
        if (user == null)
        {
            return Unauthorized("Username or password is incorrect");
        }

        var verificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, request.Password);
        if (verificationResult == PasswordVerificationResult.Failed)
        {
            return Unauthorized("Username or password is incorrect");
        }

        // Request token from IdentityServer
        using var client = new HttpClient();

        var tokenRequest = new HttpRequestMessage(HttpMethod.Post, "https://localhost:5001/connect/token");
        tokenRequest.Content = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            { "client_id", "ro.client" },
            { "client_secret", "secret" },
            { "grant_type", "password" },
            { "username", request.Username },
            { "password", request.Password },
            { "scope", "openid profile api1 offline_access" }
        });

        var tokenResponse = await client.SendAsync(tokenRequest);
        var payload = await tokenResponse.Content.ReadAsStringAsync();

        if (!tokenResponse.IsSuccessStatusCode)
        {
            var error = await tokenResponse.Content.ReadAsStringAsync();
            return Unauthorized(new { error = "Invalid login or failed to get token", details = error });

        }
        
        return Content(payload, "application/json");

        // var tokenData = JsonSerializer.Deserialize<TokenResponse>(payload);
        // return Ok(tokenData);
    }
    
    [Authorize]
    [HttpPost("add-friend")]
    public async Task<IActionResult> AddFriend(AddFriend request)
    {
        var result = await _mediator.Send(request);
        if (result)
        {
            return Ok(new { message = "Friend request sent." });
        }

        return Conflict(new { message = "Request not created (already pending/accepted, user not found, or self request)." });
    }
    
    [Authorize]
    [HttpPost("respond-friend-request")]
    public async Task<IActionResult> RespondToFriendRequest([FromBody] RespondToFriendRequest request)
    {
        var success = await _mediator.Send(request);

        if (!success)
        {
            return BadRequest( new { message = "Failed to respond to friend request" });
        }
        return Ok(new { message = "Friend request sent" });
    }
    
    [Authorize]
    [HttpGet("pending-requests")]
    public async Task<IActionResult> GetPendingRequests([FromQuery] string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            return BadRequest(new { message = "username is required" });
        
        var result = await _mediator.Send(new GetPendingFriendRequest{ Username = username } );
        return Ok(result);
    }
    
    [Authorize]
    [HttpGet("friends")]
    public async Task<IActionResult> GetFriends([FromQuery] string username)
    {
        var me = await _userRepository.GetByUsernameAsync(username);
        if (me == null) return NotFound();

        me.Friend ??= new List<ClientFriend>();

        // Only accepted friends
        var accepted = me.Friend.Where(f => f.Status == RequestStatus.Accepted).ToList();
        if (!accepted.Any()) return Ok(Array.Empty<object>());

        // Extract friend IDs
        var friendIds = accepted.Select(f => f.FriendId).ToHashSet();

        // Fetch friend user records
        var friendUsers = await _userRepository.GetUsersByIdsAsync(friendIds);

        // Map ID -> Username for easy lookup
        var usernameLookup = friendUsers.ToDictionary(u => u.Id, u => u.Username);

        // Return usernames instead of IDs
        var result = accepted.Select(f => new 
        { 
            id = f.FriendId, 
            username = usernameLookup.TryGetValue(f.FriendId, out var uname) ? uname : "(unknown)" 
        });

        return Ok(result);
    }
    
    public class TokenResponse
    {
        public string AccessToken { get; set; }
        public int ExpiresIn { get; set; }
        public string TokenType { get; set; }
        public string RefreshToken { get; set; }
    }

    [HttpPost("{id:guid}")]
    public async Task<IActionResult> GetById(Guid id) => NotFound();
}