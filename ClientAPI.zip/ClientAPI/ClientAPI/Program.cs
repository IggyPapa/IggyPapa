﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;


namespace ClientAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            
            
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    var baseDir = AppContext.BaseDirectory; // .../bin/Debug/net8.0/
                    var projectRoot = Path.GetFullPath(Path.Combine(baseDir, "..", "..", "..")); // .../ClientAPI/ClientAPI/
            
                    webBuilder
                        .UseContentRoot(projectRoot)
                        .UseWebRoot(Path.Combine(projectRoot, "wwwroot"))
                        .UseStartup<Startup>()
                        .ConfigureKestrel(serverOptions =>
                        {
                            serverOptions.ListenLocalhost(5000);
                            serverOptions.ListenLocalhost(5001, lo => lo.UseHttps());
                        });
                });
        }
    }
}