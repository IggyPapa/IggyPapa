using ClientAPI.Application;
using ClientAPI.Application.Interfaces;
using ClientAPI.IdentityServer;
using ClientAPI.Application.Users.Commands.RegisterUser;
using ClientAPI.Application.Users.Commands.AddFriend;
using ClientAPI.Infastructure;
using ClientAPI.Infastructure.MongoDB;
using ClientAPI.Infastructure.Authentication;
using ClientAPI.Domain.Entities;
using FluentValidation;
using IdentityServer4.Models;
using IdentityServer4.Test;
using MediatR;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;
using System.Reflection;
using System.Text;

using DomainClient = ClientAPI.Domain.Entities.Client;
using IdentityClient = IdentityServer4.Models.Client;



namespace ClientAPI;

public class Startup
{
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }
    
    public void ConfigureServices(IServiceCollection services)
    {

        BsonSerializer.RegisterSerializer(new GuidSerializer(GuidRepresentation.Standard));
        
        services.AddCors(options =>
        {
            options.AddPolicy("AllowAll", builder =>
                builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
        });
        
        services.AddControllers();

        services.AddIdentityServer()
            .AddInMemoryClients(Config.Clients)
            .AddInMemoryIdentityResources(Config.IdentityResources)
            .AddInMemoryApiScopes(Config.ApiScopes)
            .AddDeveloperSigningCredential()
            .AddInMemoryApiResources(Config.ApiResources)
            .AddResourceOwnerValidator<ResourceOwnerPasswordValidator>();

        services.AddAuthentication("Bearer")
            .AddJwtBearer("Bearer", options =>
            {
                options.Authority = "https://localhost:5001";
                options.RequireHttpsMetadata = false;            
                options.Audience = "api1";
            });

        services.AddAuthorization();

        services.AddMediatR(typeof(Application.Users.Commands.RegisterUser.RegisterUserHandler).Assembly);
        
        services.AddMediatR(typeof(AddFriendHandler).Assembly);

        
        services.Configure<MongoDbOptions>(
            Configuration.GetSection(nameof(MongoDbOptions)));
        // instead of nameof(MongoDbOptions) bori na prepi na valis "MongoDbSettings"
            
        //services.AddScoped<IApplicationDbContext, MongoDbContext>();
        
        services.AddSingleton<IMongoClient>(sp =>
        {
            return new MongoClient("mongodb://localhost:27017/");
        });
        
        services.AddSingleton(sp =>
        {
            var client = sp.GetRequiredService<IMongoClient>();
            return client.GetDatabase("ClientAPI");
        });
        
        // services.AddCors(o =>
        // {
        //     o.AddDefaultPolicy(p =>
        //         p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
        // });

        services.AddScoped<IApplicationDbContext, MongoDbContext>();

        services.AddScoped<IUserRepository , UserRepository>();
        
        services.AddTransient<IValidator<Application.Users.Commands.RegisterUser.RegisterUser>, Application.Users.Commands.RegisterUser.RegisterUserValidator>();
        
        services.AddScoped<IPasswordHasher<DomainClient>, PasswordHasher<DomainClient>>();
        
        services.AddSingleton<MongoDbClientFactory>();

        services.AddSingleton<IMongoDatabase>(sp =>
        {
            var client = sp.GetRequiredService<IMongoClient>();
            return client.GetDatabase("ClientAPI");
        });

        services.AddScoped<IUserRepository, UserRepository>();
        
        services.AddTransient<IValidator<RegisterUser>, RegisterUserValidator>();
        
        services.AddScoped<IPasswordHasher<DomainClient>, PasswordHasher<DomainClient>>();
        
        services.AddScoped<ResourceOwnerPasswordValidator>();
    }
    
    public IConfiguration Configuration { get; }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env) 
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        

        app.UseCors("AllowAll");

        app.UseHttpsRedirection();
        app.UseDefaultFiles();
        app.UseStaticFiles();
        
        app.UseRouting();
        
        app.UseAuthentication();
        app.UseIdentityServer();
        app.UseAuthorization();
        
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
        
        /*
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }*/
        
        // app.UseHttpsRedirection();
        // app.UseRouting();
        // app.UseIdentityServer();
        //
        // app.UseEndpoints(endpoints =>
        // {
        //     endpoints.MapControllers();
        // });
    }
}