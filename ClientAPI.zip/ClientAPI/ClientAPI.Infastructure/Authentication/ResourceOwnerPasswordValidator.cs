using ClientAPI.Application;
using ClientAPI.Application.Interfaces;
using IdentityServer4.Validation;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using IdentityServer4.Models;

using Client = ClientAPI.Domain.Entities.Client;

namespace ClientAPI.Infastructure.Authentication;

public class ResourceOwnerPasswordValidator : IResourceOwnerPasswordValidator
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher<Client> _passwordHasher;


    public ResourceOwnerPasswordValidator(IUserRepository userRepository,
        IPasswordHasher<Client> passwordHasher)
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
    }

    public async Task ValidateAsync(ResourceOwnerPasswordValidationContext context)
    {
        var client = await _userRepository.GetByUsernameAsync(context.UserName);

        if (client == null)
        {
            context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, "User not found");
            return;
        }

        var verificationResult = _passwordHasher.VerifyHashedPassword(client, client.Password, context.Password);
        if (verificationResult != PasswordVerificationResult.Success)
        {
            context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, "Invalid password");
            return;
        }

        context.Result = new GrantValidationResult(client.Id.ToString(), "password");
        /*
        var client = await _userRepository.GetByUsernameAsync(context.UserName);

        if (client == null)
        {
            context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, 
                "Invalid username or password.");
            return;
        }
        
        var verificationResult = _passwordHasher.VerifyHashedPassword(
            client, client.Password, context.Password);
        if (verificationResult != PasswordVerificationResult.Success)
        {
            context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, "Invalid username or password.");
            return;
        }*/

        //context.Result = new GrantValidationResult(client.Id.ToString(), "password");
    }
}