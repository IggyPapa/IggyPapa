using Microsoft.Extensions.Configuration;
using ClientAPI.Domain.Entities;
using ClientAPI.Application;
using ClientAPI.Application.Interfaces;
using MongoDB.Driver;
using System.Threading;
using System.Threading.Tasks;


namespace ClientAPI.Infastructure.MongoDB;

public class MongoDbContext : IApplicationDbContext
{
    private readonly IMongoDatabase _database;

    public MongoDbContext(IMongoClient mongoClient)
    {
        var client = new MongoClient("mongodb://notesco-microservices-mongodb:27017");
        _database = mongoClient.GetDatabase("ClientAPI");
        
    }
    
    public IMongoCollection<Client> Client => _database.GetCollection<Client>("Clients");

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
    {
        return Task.FromResult(0);
    }
}