using ClientAPI.Application.Interfaces;
using ClientAPI.Domain.Entities;
using ClientAPI.Domain.Enums;
using MongoDB.Driver;
using MongoDB.Bson;
using Microsoft.Extensions.Configuration;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.HttpResults;

namespace ClientAPI.Infastructure.MongoDB;

public class UserRepository : IUserRepository
{
    private readonly IMongoCollection<Client> _client;
    
    public UserRepository(IMongoDatabase database)
    {
        _client = database.GetCollection<Client>("Clients");
    }

    public async Task<Client> GetByUsernameAsync(string username)
    {
        if (string.IsNullOrWhiteSpace(username)) return null;
        username = username.Trim();

        Console.WriteLine($"GetByUsernameAsync called with: '{username}'");

        // Fast path: exact match (case sensitive)
        var exactFilter = Builders<Client>.Filter.Eq(c => c.Username, username);
        var user = await _client.Find(exactFilter).FirstOrDefaultAsync();
        if (user != null)
        {
            user.Friend ??= new List<ClientFriend>(); // normalize list on read
            Console.WriteLine($"User found (exact): {user.Username}");
            return user;
        }

        // Fallback: case-insensitive match
        var regex = new BsonRegularExpression($"^{Regex.Escape(username)}$", "i");
        var ciFilter = Builders<Client>.Filter.Regex(c => c.Username, regex);
        user = await _client.Find(ciFilter).FirstOrDefaultAsync();

        if (user != null)
        {
            user.Friend ??= new List<ClientFriend>();
            Console.WriteLine($"User found (CI): {user.Username}");
        }
        else
        {
            Console.WriteLine("User not found");
        }

        return user;
        // if (string.IsNullOrWhiteSpace(username)) return null;
        //
        // username = username.Trim();
        //
        // Console.WriteLine($"GetByUsernameAsync called with: '{username}'");
        //
        // var filter = Builders<Client>.Filter.Eq((Client c) => c.Username, username);
        // var user = await _client.Find(filter).FirstOrDefaultAsync();
        //
        // // Case sensitive
        // if (user != null)
        // {
        //     Console.WriteLine($"User found: {user.Username}");
        //     return user;
        // }
        //
        // // // Case insensitive
        // // var regex = new BsonRegularExpression($"^{Regex.Escape(username)}$", "i");
        // // var ciFilter = Builders<Client>.Filter.Regex(c => c.Username, regex);
        // // user = await _client.Find(ciFilter).FirstOrDefaultAsync();
        //
        // Console.WriteLine(user == null ? "User not found" : $"User found (CI): {user.Username}");
        //
        // return user;
        
    }
    
    public async Task<bool> UsernameExistsAsync(string username)
    {
        if (string.IsNullOrWhiteSpace(username)) return false;

        username = username.Trim();
        var filter = Builders<Client>.Filter.Eq(c => c.Username, username);
        var count = await _client.CountDocumentsAsync(filter);
        return count > 0;
    }

    public async Task<List<Client>> GetUsersByFriendPendingAsync(Guid friendId)
    {
        var filter = Builders<Client>.Filter.ElemMatch(c => c.Friend,
            f => f.FriendId == friendId && f.Status == RequestStatus.Pending);
        return await _client.Find(filter).ToListAsync();
    }
    
    public async Task<List<Client>> GetUsersByIdsAsync(IEnumerable<Guid> ids)
    {
        var idList = ids?.Distinct().ToList() ?? new List<Guid>();
        if (!idList.Any()) return new List<Client>();

        var filter = Builders<Client>.Filter.In(c => c.Id, idList);
        return await _client.Find(filter).ToListAsync();
    }
    
    public async Task UpdateAsync(Client client)
    {
        await _client.ReplaceOneAsync(c => c.Id == client.Id, client);
    }
}