using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace ClientAPI.Infastructure.MongoDB;

public class MongoDbClientFactory
{
    private readonly IOptions<MongoDbOptions> _options;
    private readonly IMongoClient _mongoClient;
    private readonly string _databaseName;

    public MongoDbClientFactory(IOptions<MongoDbOptions> options)
    {
        _options = options;
        _mongoClient = new MongoClient(_options.Value.ConnectionString);
        _databaseName = _options.Value.DatabaseName;
    }

    public IMongoClient GetClient()
    {
        //var clientSettings = MongoClientSettings.FromConnectionString(_options.Value.ConnectionString);

        return _mongoClient;
        
    }

    
}