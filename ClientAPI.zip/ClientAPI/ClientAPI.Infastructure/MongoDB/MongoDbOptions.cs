namespace ClientAPI.Infastructure.MongoDB;

public class MongoDbOptions
{
    public string ConnectionString { get; set; }
    public string DatabaseName { get; set; }
}